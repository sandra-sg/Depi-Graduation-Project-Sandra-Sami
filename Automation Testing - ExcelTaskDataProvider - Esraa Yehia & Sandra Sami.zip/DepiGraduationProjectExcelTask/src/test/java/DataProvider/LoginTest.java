package DataProvider;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
public class LoginTest {

        WebDriver driver;

        @BeforeMethod
        void SetUp() {
            driver = new ChromeDriver();
            driver.get("https://the-internet.herokuapp.com/login");
            driver.manage().window().maximize();
        }

        // DataProvider to supply login credentials from Excel
        @DataProvider(name = "loginData")
        public Object[][] loginData() {
            String excelFilePath = "C:\\Users\\sandra\\Downloads\\LoginCredentials.xlsx";
            return ExcelUtils.getExcelData(excelFilePath);
        }

        // Test method using data from the DataProvider
        @Test(dataProvider = "loginData")
        public void loginTest(String username, String password) {
            // Enter username and password and click login
            driver.findElement(By.id("username")).sendKeys(username);
            driver.findElement(By.id("password")).sendKeys(password);
            driver.findElement(By.className("fa-sign-in")).click();

            //  add assertions here to verify login success or failure
            System.out.println("Login attempted with Username: " + username + " and Password: " + password);
        }

        @AfterMethod
        void Quit() {
            driver.quit(); // Close browser after test
        }
    }


